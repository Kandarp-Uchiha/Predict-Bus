import React from "react";

const Contact = () => {
  return (
    <div>
      <div>Contact US </div>
    </div>
  );
};

export default Contact;
